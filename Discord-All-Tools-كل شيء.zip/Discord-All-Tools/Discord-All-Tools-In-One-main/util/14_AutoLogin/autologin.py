import requests
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from colorama import Fore, init

# Initialize colorama for cross-platform colored output
init()

def autologin():
    # Custom functions (assumed to exist in your environment)
    def clear(): print("\033[H\033[J", end="")  # Placeholder for clear
    def setTitle(title): print(f"Title: {title}")  # Placeholder for setTitle
    def autologintitle(): print(f"{Fore.YELLOW}[Auto Login]{Fore.RESET}")  # Placeholder
    def main(): print("Returning to main menu...")  # Placeholder

    clear()
    autologintitle()
    setTitle("Auto Login")

    # Get token from user
    print(f"{Fore.YELLOW}[{Fore.WHITE}+{Fore.YELLOW}]{Fore.WHITE} Enter the token of the account you want to connect to")
    token = input(f"{Fore.YELLOW}[{Fore.BLUE}#{Fore.YELLOW}]{Fore.WHITE} Token: ").strip()

    # Validate token
    headers = {'Authorization': token, 'Content-Type': 'application/json'}
    try:
        response = requests.get('https://discord.com/api/v9/users/@me', headers=headers, timeout=5)
        if response.status_code != 200:
            print(f"\n{Fore.YELLOW}[{Fore.LIGHTRED_EX}!{Fore.YELLOW}]{Fore.WHITE} Invalid token")
            input(f"\n{Fore.YELLOW}[{Fore.BLUE}#{Fore.YELLOW}]{Fore.WHITE} Press ENTER to exit")
            main()
            return
    except requests.RequestException as e:
        print(f"\n{Fore.YELLOW}[{Fore.LIGHTRED_EX}!{Fore.YELLOW}]{Fore.WHITE} Failed to validate token: {e}")
        input(f"\n{Fore.YELLOW}[{Fore.BLUE}#{Fore.YELLOW}]{Fore.WHITE} Press ENTER to exit")
        main()
        return

    # Set up Selenium WebDriver
    try:
        # Automatically manage ChromeDriver
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service)
        driver.maximize_window()
        driver.get('https://discord.com/login')

        # JavaScript to set token and reload
        js = '''
        function login(token) {
            setInterval(() => {
                document.body.appendChild(document.createElement('iframe')).contentWindow.localStorage.token = `"${token}"`;
            }, 50);
            setTimeout(() => {
                location.reload();
            }, 500);
        }
        '''
        driver.execute_script(js + f'login("{token}")')

        # Wait for login to complete (up to 15 seconds)
        for _ in range(15):
            if driver.current_url != 'https://discord.com/login':
                clear()
                autologintitle()
                print(f"{Fore.YELLOW}[{Fore.LIGHTGREEN_EX}!{Fore.YELLOW}]{Fore.WHITE} Connection Established")
                break
            time.sleep(1)
        else:
            clear()
            autologintitle()
            print(f"{Fore.YELLOW}[{Fore.LIGHTRED_EX}!{Fore.YELLOW}]{Fore.WHITE} Connection Failed")

        driver.quit()
        input(f"{Fore.YELLOW}[{Fore.BLUE}#{Fore.YELLOW}]{Fore.WHITE} Press ENTER to exit")
        main()

    except Exception as e:
        print(f"{Fore.YELLOW}[{Fore.LIGHTRED_EX}!{Fore.YELLOW}]{Fore.WHITE} A problem occurred: {e}")
        if 'driver' in locals():
            driver.quit()
        time.sleep(2)
        clear()
        main()

if __name__ == "__main__":
    autologin()